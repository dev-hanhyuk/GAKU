import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { MatTabsModule } from '@angular/material/tabs';

import { ProductsModule } from './products/products.module';
import { AuthModule } from './auth/auth.module';
import { PageNotFoundComponent }   from './not-found.component';
import { FooterComponent } from './footer/footer.component';


@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ProductsModule,
    AuthModule,
    AppRoutingModule,
    MatTabsModule
  ],
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    FooterComponent
  ],
  providers: [],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
