import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

export class Product {
    constructor(
        public id: number, 
        public name: string,
        public price: number,
        public description: string,
        public cols: number,
        public rows: number,
        public color: string,
        public image_url: string
    ) {}
}

const PRODUCTS = [
    new Product(10011, 'Cardboard', 35.99, 'Short ribs ball tip prosciutto, strip steak chuck ham ribeye. Kielbasa doner ham hock biltong ground round t-bone.', 3, 1, 'lightblue', '../assets/cardboard.png'),
    new Product(10012, 'Thermostat', 11.99, 'Kielbasa pork loin drumstick kevin. Pork belly swine frankfurter burgdoggen andouille. Beef ribs spare ribs chicken turducken pig.', 1, 2, 'lightgreen', '../assets/thermostat.png'),
    new Product(10013, 'Watch', 14.00, 'Doner tail cupim, andouille kielbasa cow ribeye shoulder buffalo frankfurter beef ribs burgdoggen chicken jerky.', 1, 1, 'lightpink', '../assets/watch.png'),
    new Product(10014, 'Phone', 15.50, 'Beef ribs short ribs jerky doner tenderloin buffalo shank venison sausage filet mignon.', 2, 1, '#DDBDF1', '../assets/phone.png')
];


@Injectable()
export class ProductService {
    getProducts() { return Observable.of(PRODUCTS); }

    getProduct(id: number | string) {
        return this.getProducts()
            .map(products => products.find(product => product.id === +id))
    }
}

